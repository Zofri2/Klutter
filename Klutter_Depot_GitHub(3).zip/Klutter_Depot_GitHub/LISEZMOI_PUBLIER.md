# Publier Klutter avec un vrai lien de téléchargement

GitHub construit l'installateur Windows pour toi (gratuit) et l'héberge.

1. Crée un compte sur github.com, puis un dépôt vide nommé **Klutter** (public, sinon le lien ne marche pas pour les autres).
2. Sur la page du dépôt : « uploading an existing file », glisse **tout le contenu de ce dossier**, y compris le dossier caché `.github` (s'il n'apparaît pas, active « Afficher les éléments masqués » dans l'Explorateur Windows), puis « Commit changes ».
3. Onglet **Releases** → « Create a new release » → dans « Choose a tag », écris `v1.0` → « Create new tag » → « Publish release ».
4. Onglet **Actions** : le build démarre (environ 10 minutes). Quand il est vert, retourne dans Releases : `Installateur_Klutter.exe` est attaché à la version `v1.0`.
5. Le lien direct de téléchargement est :
   `https://github.com/TON_PSEUDO/Klutter/releases/latest/download/Installateur_Klutter.exe`
6. Donne-moi ce lien : je le mets dans la page web.

Pour une mise à jour : modifie `trieur_photos.py` dans le dépôt, puis crée une release `v1.1`, etc.

## Mettre le site en ligne gratuitement (GitHub Pages)
Le fichier `index.html` de ce dossier est le site.
1. Dans ton dépôt : **Settings** → **Pages**.
2. « Source » : **Deploy from a branch** ; Branch : **main**, dossier **/ (root)** → **Save**.
3. Après une minute, ton site est en ligne à `https://TON_PSEUDO.github.io/Klutter/`.
4. Ouvre `index.html` dans GitHub (crayon « Edit »), trouve la ligne `var DOWNLOAD_URL = "";` et mets-y le lien de téléchargement entre les guillemets. Remplace aussi `[ton nom]` et `[ton adresse e-mail]`.
